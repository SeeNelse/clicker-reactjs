import React from 'react';

const Counter = ({CurrentCounter}) => {
  return(
    <h4 className="counter">{ CurrentCounter }</h4>
  )
}

export default Counter;